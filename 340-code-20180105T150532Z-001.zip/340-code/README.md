# 340-Code
Scientific Computing Code

This code was used for manipulating matrices. The Points.py file was used to help develop an answer to a Travelling salesman problem (CSC 340, UNCW, Spring 2016).
